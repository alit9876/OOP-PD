﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACMAN.GL
{
    enum GameDirection
    {
        Left,
        Right,
        Up,
        Down
    }
}
